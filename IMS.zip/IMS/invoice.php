<?php 
session_start();
    $cname=$_SESSION['cname'];
    $pid=$_SESSION['pid'];
    $pname=$_SESSION['pname'];
    $ppu=(int)$_SESSION['ppu'];
    $quantity=(int)$_SESSION['quantity'];
    $cnum=$_SESSION['cnum'];
    $gtotal=$_SESSION['gtotal'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>invoice</title>
    <style>
        body {
            margin-top: 10%;
            background-color: #faf1f1;
            width: 59%;
            padding: 0;
            margin-left: 22%;
        }
        h1,h2,h3,h4,h5,h6{
            margin: 0;
            padding: 0;
        }
        p{
            margin: 0;
            padding: 0;
            text-align: right;
            color: white;
        }
        .container{
            width: 80%;
            margin-right: auto;
            margin-left: auto;
        }
        .brand-section{
           background-color: #373d42;
           padding: 10px 40px;
        }
        .logo{
            width: 50%;
        }

        .row{
            display: flex;
            flex-wrap: wrap;
        }
        .col-6{
            width: 50%;
            flex: 0 0 auto;
        }
        .text-white{
            color: #fff;
        }
        .company-details{
            float: right;
            text-align: right;
        }
        .body-section{
            padding: 16px;
            border: 1px solid gray;
            
        }
        .heading{
            font-size: 20px;
            margin-bottom: 08px;
        }
        .sub-heading{
            color: #262626;
            margin-bottom: 05px;
        }
        table{
            background-color: #fff;
            width: 100%;
            border-collapse: collapse;
        }
        table thead tr{
            border: 1px solid #111;
            background-color: #f2f2f2;
        }
        table td {
            vertical-align: middle !important;
            text-align: center;
        }
        table th, table td {
            padding-top: 08px;
            padding-bottom: 08px;
        }
        .table-bordered{
            box-shadow: 0px 0px 5px 0.5px gray;
        }
        .table-bordered td, .table-bordered th {
            border: 1px solid #dee2e6;
        }
        .text-right{
            text-align: end;
        }
        .w-20{
            width: 15%;
        }
        .headingdate{
            background: #faf1f1;
            width:20%;
            font-size: 15;
            font-family: times new roman;
        }
        .orderdate{
            margin-left:0px;
         
            
        }
        .backbtn {
            margin-left: 47%;
            margin-top: 3%;
            padding: 10px 20px;
            border-radius: 13px;
        }
        
    </style>
</head>
<body>

    <div class="container">
        <div class="brand-section">
            <div class="row">
                <div class="col-6">
                    <h1 class="text-white">CREZZA Italian Furnitures</h1>
                </div>
                <div class="col-6">
                    <p>Address - Block-67,Gandhi Nagar,Gujrat</p>
                    <p>Email id - inventory@gmail.com</p>
                    <p>Contact - 5674837456</p>                  
                </div>
            </div>
        </div>

        <div class="body-section">
            <div class="row">
                <div class="col-6">
                    <table class ="infotable">
                        <?php echo '<tr class="sub-heading">Customer Name: '.$cname.' </tr><br><br>
                        <tr class="sub-heading">Contact Number: '.$cnum.' </tr><br>' ?>
                        
                    </table>
                  
                </div>
                <div class="col-6">
               
                <table class="headingdate" >
                        
                    <!-- <tr
                         class="orderdate">Billing Date:</tr>
                         
                    </tr>
                    <br><br>
                    <tr
                         class="orderno">Order no.:</tr>
                         
                    </tr> -->
                
        </table>
                </div>
            </div>
        </div>

        <div class="body-section">
            <h3 class="heading">Ordered Items</h3>
            <br>
            <table class="table-bordered">
                <thead>
                    <tr>
                        <th>Product name</th>
                        <th class="w-20">Price per unit</th>
                        <th class="w-20">Quantity</th>
                        <th class="w-20">Grandtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <h5>php code</h5> -->
                    <?php echo '<tr>
                       <td>'.$pname.'</td>
                       <td>'.$ppu.'</td>
                       <td>'.$quantity.'</td>
                       <td>'.$gtotal.'</td>
                   </tr>'?>
                </tbody>
            </table>
            
            <table>
                <br>
            <tr class="heading">Payment Status: Paid</tr><br><br>
            <tr class="heading">Payment Mode: Offline</tr>
        </table>
        </div>

        <div class="body-section">
           <i>Have a nice day!!</i> 
              
           
        </div>      

        <a href="home.php"><button class='backbtn'>Go back</button></a>
    </div>      

</body>
</html>
