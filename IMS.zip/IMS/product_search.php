<?php
session_start();
include('db_connection.php');

if($_GET){
  $pid = $_GET['pid'];
  $product_details_query = "SELECT p_name,price_per_unit FROM products WHERE p_id = '$pid'";
  $product_details = $conn->query($product_details_query)->fetch();
  if($product_details[0]=='' || $product_details[1]==''){
  	$product_details[0]='not selected';
  }
  $_SESSION['pname'] = $product_details[0];
  $_SESSION['ppu'] = $product_details[1];
  $_SESSION['pid'] = $pid;
  header('location:billing.php');
  // echo 'product details: '.$product_details[0].' ppu: '.$product_details[1].'';
}
?>