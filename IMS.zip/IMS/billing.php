<?php
session_start();
include('db_connection.php');
$empid = $_SESSION['empid'];
// $stmt=$conn->query("SELECT CURRENT_DATE()");
// $curr_date =$stmt->execute();
$pid=$_SESSION['pid'];
$pname=$_SESSION['pname'];
$ppu=(int)$_SESSION['ppu'];

if($_POST){
  $cname=$_POST['cname'];
  // $pid=$_POST['pid'];
  // $pname=$_POST['pname'];
  $quantity=(int)$_POST['quantity'];
  $cnum=$_POST['cnum'];
  $gtotal=$ppu*$quantity;

  $_SESSION['cname'] = $cname;
  $_SESSION['pid'] = $pid;
  $_SESSION['pname'] = $pname;
  $_SESSION['ppu'] = $ppu;
  $_SESSION['quantity'] = $quantity;
  $_SESSION['cnum'] = $cnum;
  $_SESSION['gtotal'] = $gtotal;

  $cust_insert_query = "INSERT INTO customers (c_name, c_phone) VALUES ('$cname','$cnum')";
  $order_query = "INSERT INTO orders (p_id,quantity,product_name,price) VALUES ('$pid',$quantity,'$pname',$gtotal)";
  $update_stock_query = "UPDATE products SET quantity = quantity - $quantity WHERE p_id = '$pid'";
  $present_quantity_query = "SELECT quantity FROM products WHERE p_id = '$pid'";

  //Checking if we have enough stocks

  $stmt = $conn->query($present_quantity_query);
  $present_quantity = $stmt->fetch();

  try {
    if((int)$present_quantity[0]==0){
      throw new Exception("Out of Stock:".$pid."");
    }
    elseif((int)$present_quantity[0] <= $quantity){
      throw new Exception('Stock Shortage, available:'.$present_quantity[0].'for product: '.$product_details[0].'');
    }
    if ($conn->exec($cust_insert_query)>0 && $conn->exec($order_query)>0){
      $conn->exec($update_stock_query);
      header('location:invoice.php');
    }
  } catch (Exception $e) {
    echo 
    '<div id = "errorMessage">
    <h4>Error:'.$e->getMessage().'</h4>
    </div>';
  }
}  
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="css/home.css">
  <link rel="stylesheet" href="css/billing.css">


  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <?php include 'include/sidemenu.php';?>

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="home">Billing</span>
      </div>

      <!-- include statement for the Employee ID display in the top right -->
      <?php include 'include/iddisplay.php';?>
    </nav>
    <div class="home-content">    
      <!-- <img src="images/billing.jpg"> -->
    </div>
    <form action="product_search.php" method="GET">
              <label class="product_search" for="Pid">Product Id :</label>
              <input type="text" id="pid" name="pid">
              <button class="p_searchbtn">search</button></p> 
            </form>
    <form action ="billing.php" method="POST">

      <!-- Details -->
      <div >
        <div class="content">

          <div class="column">

            <br>
            <label for="cname">Customer name :</label> 
            <input type="text" id="cname" name="cname"> </p>

           <!--  <form action="billing.php" method="POST">
              <label for="Pid">Product Id :</label>
              <input type="text" id="pid" name="pid">
              <button class="p_searchbtn">search</button></p> 
            </form> -->
            
            <label for="Pname">Product name :</label>
            <?php
              echo '<h4 class = "product_details">'.$pname.'</h4>';
            ?>
            <!-- <input type="text" id="pname" name="pname"> -->

            

            <div class ="unitp">
              <label for="pu">Price per unit : </label>
              <?php
                echo '<h4 class = "product_details">'.$ppu.'</h4>';
              ?>
              <!-- <input type="text" id="ppu" name="ppu"> -->
            </div>
            <div class="form-control">
              <div class="">

                <!-- <label for="pcat">Product Category:</label>

                <select name="cat" id="cat" class="input">

                  <option value="none">--Select--</option>
                  <option value="bd">Bedroom</option>
                  <option value="lr">Living room</option>
                  <option value="dr">Dining room</option>
                  <option value="sr">Study Room</option>
                </select> -->
                <div class ="ptm">
                  <!-- <label for="Pm">Payment Method :</label>
                  <select name="pm" id="pm">
                    <option value="none">--Select--</option>
                    <option value="Online">Online</option>
                    <option value="Off">Offline</option>
                  </select> -->

                  <div class ="qtyname"><br>
                    <label for="Qty">Quantity :</label>
                    <input type="text" id="quantity" name="quantity"> 
                    <!-- </div> -->
                    <div>
                      <label for="cnum">Ph No. :</label>
                      <input type="text" id="cnum" name="cnum">  
                    </div>
                  </div><br><br>
                  <div class ="inner">
                    <button type ="submit" class="printbtn">Print</button>
                    <button type="reset" value="Reset" class="resetbtn">Reset</button>  
                  </div>
                </div>
              </div>  
            <!-- <div class ="bdate"> 
              <label for="bd">Bill date : </label> -->
              <!-- <input type="text" id="orderdate" name="orderdate"> -->
              <?php
                // echo '<text>'.$curr_date.'</text>';
              ?>
              <!-- </div> -->
            </div>
          </form> 
          
          <!-- <button class="totalBtn" disabled>Total</button><input type="text" id="totalprice" name="totalprice">  -->
        </div> 
        <script>
         let sidebar = document.querySelector(".sidebar");
         let sidebarBtn = document.querySelector(".sidebarBtn");
         sidebarBtn.onclick = function() {
          sidebar.classList.toggle("active");
          if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
          }else
          sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        }
      </script>
  </body>
</html>

