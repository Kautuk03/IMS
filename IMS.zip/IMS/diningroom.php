<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/home.css">
    
     <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

   <style type="text/css">


    *{
     margin: 0px;
     padding: 0px;
    }
    body{
     font-family: arial;
    }
    .main{
    
     margin: 0%;
    }
    
    .card{
         width: 20%;
         display: inline-block;
         box-shadow: 2px 2px 20px black;
         border-radius: 5px; 
         margin: 2%;
         padding: 0px;
         margin-top: 10%;
        }
    
    .image img{
      width: 100%;
      border-top-right-radius: 5px;
      border-top-left-radius: 5px;
      
    
     
     }
    
    .title{
     
      text-align: center;
      padding: 10px;
      
     }
    
    h1{
      font-size: 20px;
     }
    
    .des{
      padding: 3px;
      text-align: center;
     
      padding-top: 10px;
            border-bottom-right-radius: 5px;
      border-bottom-left-radius: 5px;
    }
    button{
      margin-top: 40px;
      margin-bottom: 10px;
      background-color: white;
      border: 1px solid black;
      border-radius: 5px;
      padding:10px;
    }
    button:hover{
      background-color: black;
      color: white;
      transition: .5s;
      cursor: pointer;
    }
    
    </style>
<body>
  <?php include 'include/sidemenu.php';?>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="home">Dinning Room</span>
      </div>
      
      
    </nav>
    <div class="#">
        <div class="main">

            <!--cards -->
           
           <div class="card">
           
           <div class="image">
              <img src="images/dining-table.jfif">
           </div>
           <div class="title">
            <h1>
           Dining Table</h1>
           </div>
           
           </div>
           <!--cards -->
           
           
           <div class="card">
           
           <div class="image">
              <img src="images/crockery-unit.jpg">
           </div>
           <div class="title">
            <h1>
           Crockery Unit</h1>
           </div>
           
           </div>
           <!--cards -->
           
           
           </div>

    </div>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>

