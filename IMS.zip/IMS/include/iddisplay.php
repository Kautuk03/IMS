<div class="profile-details" id="result_name">
        <h2>    
                <span id="result_name" class="admin_name"><?= $empid ?></span>
        </h2>
        
</div>