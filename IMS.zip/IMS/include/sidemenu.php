<div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">IMS</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="home.php">
          <i class='bx bx-home' ></i>
          <span class="links_name">Home</span>
        </a>
      </li>
      <li>
        <a href="gallery.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Gallery</span>
        </a>
      </li>
      <li>
        <a href="billing.php">
          <i class='bx bx-list-ul' ></i>
          <span class="links_name">Billing</span>
        </a>
      </li>
      <li>
        <a href="stock-details.php">
          <i class='bx bx-coin-stack' ></i>
          <span class="links_name">Stock Details</span>
        </a>
      </li>

      <li>
        <a href="customer-details.php">
          <i class='bx bx-user' ></i>
          <span class="links_name">Customer Details</span>
        </a>
      </li>


      <li class="log_out">
        <a href="index.php">
          <i class='bx bx-log-out'></i>
          <span class="links_name">Log out</span>
        </a>
      </li>
    </ul>
  </div>