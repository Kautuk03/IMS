<?php
	session_start();
	$error_message='';

	if($_POST){
		include('db_connection.php');

		$empid=$_POST['empid'];
		$password=$_POST['password'];
		try {
			if(!empty($empid) && !empty($password)){
				$query = 'SELECT * FROM users WHERE users.empid="'.$empid.'" AND users.password="'.$password.'"';
				$stmt = $conn->prepare($query);
				$result = $stmt->execute();

				if($stmt->rowCount()>0){
					$stmt->setFetchMode(PDO::FETCH_ASSOC);
					$user = $stmt->fetchAll()[0];
					$_SESSION['user'] = $user;
					$_SESSION['empid'] = $empid;
					header('location:home.php');
					var_dump($stmt->fetchAll());
					die;
		
				}else{
					$error_message='Please make sure that the username and password are correct';
				}
			}else{
				$error_message='Please make sure that the username and password are correct';
			}
		} catch (Exception $e) {
			$error_message = $e->getMessage();
		}
		

		
	}

?>

<!DOCTYPE html> 

<html lang="en"> 

<head> 

	<meta charset="UTF-8"> 

	<title>IMS Login</title> 

	<link rel="stylesheet" href="css/login.css"> 


</head> 

<body background="images/index.jpg" > 

	<?php if(!empty($error_message)) { ?>
					<div id = 'errorMessage'>
						<h3>Error: <?= $error_message ?> </h3>
					</div>
	<?php } ?>

	<div class="content"> 

		<div class="container mt-5" id="container"> 

			<div class="form-container sign-up-container mt-2"> 

				<form action="sign_up.php" method="POST"> 

					<h1 class="font-weight-bold">Create Account</h1> 

					<input type="text" placeholder="Employee ID" name = empid required/> 

					<input type="email" placeholder="Email" name = email required/> 

					<input type="password" placeholder="Password" name = password required/> 

					<button ondblclick="myalert()" class="btn btn-info btn-rounded">Sign up</button> 

				</form> 

			</div> 


			<div class="form-container sign-in-container"> 

				

				<form action="index.php" method="POST"> 

					<h1 class="font-weight-bold">Sign in</h1> 



					<input type="text" placeholder="Employee ID" name = empid required/> 

					<input type="password" placeholder="Password" name="password" required/> 

					<button class="btn btn-info btn-rounded ">Sign In</button> 

				</form> 

			</div> 



			<div class="overlay-container"> 

				<div class="overlay"> 

					<div class="overlay-panel overlay-left"> 

						<img class="logo" src="images/logo.png">
						<!-- <i class="font-weight-bold">Good to see you!</i> 

						<p>Have an account? <br>Sign in!</p>  -->
						<br>
						<button class="but" id="signIn">Sign In</button> 

					</div> 

					<div class="overlay-panel overlay-right"> 
						<img class="logo" src="images/logo.png">
						<!-- <i class="font-weight-bold">Welcome to CREZZA!</i>  -->

						<!-- <p>&nbsp Join us in our journey!</p>  -->
						<br>
						<button class="but" id="signUp">Sign Up</button> 

					</div> 

				</div> 

			</div> 

		</div> 

	</div> 

	<script> 

		const signUpButton = document.getElementById('signUp'); 

		const signInButton = document.getElementById('signIn'); 

		const container = document.getElementById('container'); 




		signUpButton.addEventListener('click', () => { 

			container.classList.add('right-panel-active'); 

		}); 




		signInButton.addEventListener('click', () => { 

			container.classList.remove('right-panel-active'); 

		}); 

	</script> 



</body> 



</html> 