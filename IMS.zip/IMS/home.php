<?php
  session_start();
  $empid = $_SESSION['empid'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="css/home.css">

  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <?php include 'include/sidemenu.php';?>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="home">Home</span>
      </div>
      
      
      <!-- include statement for the Employee ID display in the top right -->
      <?php include 'include/iddisplay.php';?>
      
    </nav>
    <div class="home-content">
      <div class="home-image"><img class="imagesfullres" src="images/sofa.jpg" id="home"/>
        <div class="container">
          <img src="images/logo.png" width=150px height=150px/>
        </div>
      </div>
    </div>

    <script>
     let sidebar = document.querySelector(".sidebar");
     let sidebarBtn = document.querySelector(".sidebarBtn");
     sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
      if(sidebar.classList.contains("active")){
        sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
      }else
      sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
  </script>

</body>
</html>

