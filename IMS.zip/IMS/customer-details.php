
<?php 
session_start();
include('db_connection.php');
$empid = $_SESSION['empid'];

if($_POST){
  $phnum=(int)$_POST['phnum'];
  $cust_search_query = "SELECT * FROM customers WHERE c_phone = '$phnum'";
  $data = $conn->query($cust_search_query);
}else{
  $query="select * from customers"; 
  $data = $conn->query($query);
}
?> 

<!DOCTYPE html>

<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">

  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="css/home.css">

</head>
<body>
  <?php include 'include/sidemenu.php';?>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="home">Customer Details</span>
      </div>
      
      <!-- include statement for the Employee ID display in the top right -->
      <?php include 'include/iddisplay.php';?>
      
    </nav>
    <div class="pagedetails">
      <div class="cust_search_form">
      <form action="customer-details.php" method="POST">
        <label>
          Customer Phone Number: 
        </label>
        <input class="phnum_input" type="text" placeholder="Ph. No" name="phnum" required/> 
        <button class="searchbtn">Search</button>
      </form>
      <a href="customer-details.php"><img class="reseticon" src="images/reset.png"><!-- <button class="resetbtn">Reset</button> --></a>
      </div>
      <table class="tablestyle">
        <tr>    
          <th> Customer ID </th> 
          <th> Customer Name </th> 
          <th> Phone Number  </th> 
        </tr> 


        <?php
        foreach($data as $row){
          echo '<tr>
          <td>'.$row['c_id'].'</td>
          <td>'.$row['c_name'].'</td>
          <td>'.$row['c_phone'].'</td>
          </tr>';

        }

        ?> 

      </table> 
    </div>
    <script>
      let sidebar = document.querySelector(".sidebar");
      let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function() {
        sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
          sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
        } else
        sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
      }
    </script>

  </body>
  </html>

