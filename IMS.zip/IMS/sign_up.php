<?php
	$message = "Registeration Successfull";
	if($_POST){
		include('db_connection.php');

		$empid = $_POST['empid'];
		$email = $_POST['email'];
		$password = $_POST['password'];

		$query = "INSERT INTO users (empid, email, password) VALUES ('$empid','$email','$password')";
		try {
			if ($conn->exec($query)>0){
				echo '<h4>Message:'.$message.'</h4>';// not seen in UI 
				header('location:index.php');
		    }
		} catch (Exception $e) {
			echo '<h4>User registration failed, please ensure to fill valid details!</h4>';
		}
			
	}
?>		