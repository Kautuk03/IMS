 
<?php 
session_start();
include('db_connection.php');
$query="select * from products"; 
$data = $conn->query($query);
$empid = $_SESSION['empid'];
?>

<!DOCTYPE html>

<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">

  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="css/home.css">
</head>
<body>
  <?php include 'include/sidemenu.php';?>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="home">Stock Details</span>
      </div>

      <!-- include statement for the Employee ID display in the top right -->
      <?php include 'include/iddisplay.php';?>
      
    </nav>
    
    <div class="pagedetails">
      <table class="tablestyle">
        <tr>  
          <th> Product ID </th> 
          <th> Product Name </th> 
          <th> Quantity </th> 
        </tr> 
        <?php
        foreach($data as $row){
          echo '<tr>
          <td>'.$row['p_id'].'</td>
          <td>'.$row['p_name'].'</td>
          <td>'.$row['quantity'].'</td>
          </tr>';
        }

        ?>

      </table> 
    </div>

    <script>
     let sidebar = document.querySelector(".sidebar");
     let sidebarBtn = document.querySelector(".sidebarBtn");
     sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
      if(sidebar.classList.contains("active")){
        sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
      }else
      sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
  </script>

</body>
</html>

